--DROP TABLE TBarker_KeyPhrases
--DROP TABLE TBarker_Tweets

CREATE TABLE TBarker_Tweets
(
	TweetKey  int IDENTITY(1,1) PRIMARY KEY NOT NULL,
	TweetID varchar(25) not null,
	TweetText nvarchar(2000) NOT NULL,
	Username varchar(50) NULL,
	UserLocation varchar(100) NULL,
	TweetDate datetime NOT NULL,
	SentimentScore decimal(10,8) NULL
)

CREATE TABLE TBarker_KeyPhrases
(
	TweetID varchar(25) Not null,
	KeyPhrase varchar(2000) not null
)

SELECT
	*
FROM
	TBarker_KeyPhrases

SELECT
	*
FROM
	TBarker_Tweets