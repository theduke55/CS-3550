import pyodbc
import tweepy
from tweepy import OAuthHandler
import requests
import json

# SQL Connection Information

server = '13.66.153.161'
database = 'trevorbarker'
username = 'trevorbarker'
password = 'Fusako55!'

#Connection to SQL Server
connection_string = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database
connection_string = connection_string + ';UID=' + username + ';PWD=' + password

open_connection = pyodbc.connect(connection_string, timeout=60)
openCursor = open_connection.cursor()

# All the important information you were asked to collect from Twitter

twitterKey = 'ucVLxbh2I0jyzBgj6lix4MOrL'
twitterSecret = 'rRdCXNwVcHfSN2nnwaQDbjSllJkz4yP4jdPDAYrkEqc1Q8bbXa'
accessToken = '1111444824056430593-iSiyDugQKYNzLc8m4wRwJhIwEOB9Sq'
accessSecret = 'IQcloaExgyQnSmvR6HYC8fmzVZGbtjpedDNXKETgMsuBT'

# API call information
subscription_key = 'fefa19a1c31d4e63b16590abe38ffbdd'
assert subscription_key

base_url = "https://westus2.api.cognitive.microsoft.com"
text_analytics_base_url = base_url + "/text/analytics/v2.0/"

headers = {"Ocp-Apim-Subscription-Key": subscription_key, "Content-Type": "application/json"}

# Authenticate your app
auth = OAuthHandler(twitterKey, twitterSecret)
auth.set_access_token(accessToken, accessSecret)

# Opens a connection to twitter - respecting rate limits (so you don't get stopped
apiAccess = tweepy.API(auth, wait_on_rate_limit=True)

# q is your search string.  lang is the language you want.  count tells the system how much to
#  bring back per call.  .items takes a value that represents the total number of items you
#  want back.

api_document = []
count = 1

for tweet in tweepy.Cursor(apiAccess.search, q='Dota 2 -filter:retweets', lang='en', tweet_mode="extended").items(2000):
    tweet_id = tweet.id
    tweet_text = tweet.full_text
    tweet_name = tweet.user.name
    tweet_location = tweet.user.location
    tweet_date = str(tweet.created_at.month) + "/" + str(tweet.created_at.day) + "/" + str(tweet.created_at.year)
    api_document.append({'id': str(tweet_id), 'language': 'en', 'text': tweet_text})
    post_data = {'documents': api_document}

    sentiment_api_url = text_analytics_base_url + "sentiment"

    response = requests.post(sentiment_api_url, headers=headers, json=post_data)
    sentiments = response.json()

    for document in sentiments['documents']:
        tweet_score = document['score']
        print("Tweet #: " + str(count))
        print("Tweet: " + tweet_text)
        print("Tweet Score: " + str(tweet_score))

        sqlTweet = "INSERT TBarker_Tweets (TweetID, TweetText, UserName, UserLocation, TweetDate, SentimentScore) VALUES (?, ?, ?, ?, ?, ?)"
        tweet_args = tweet_id, tweet_text.replace('\'', '""'), tweet_name, tweet_location, tweet_date, float(tweet_score)
        openCursor.execute(sqlTweet, tweet_args)
        open_connection.commit()
        count += 1

    key_phrases_api_url = text_analytics_base_url + 'keyPhrases'
    response = requests.post(key_phrases_api_url, headers=headers, json=post_data)
    key_phrases = response.json()

    for result in key_phrases['documents']:
        for phrase in result['keyPhrases']:
            print("KeyPhrase: " + phrase)

            sqlKeyPhrases = "INSERT TBarker_KeyPhrases (TweetID, KeyPhrase) VALUES (?, ?)"
            keyphrase_args = tweet_id, phrase

            openCursor.execute(sqlKeyPhrases, keyphrase_args)
            open_connection.commit()

    api_document.clear()
openCursor.close()
open_connection.close